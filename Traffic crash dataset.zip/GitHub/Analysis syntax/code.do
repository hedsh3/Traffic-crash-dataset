*Average Treatment effects using binomial regression models in rsepctive files
xtnbreg Crash Time Treatment TreatmentXTime Distance_citycenter User Street_intersection Floor_area_ratio Speed Housing_price Entropy Bus_stop Third_street Second_street Fourth_street Parking_site Transfer_station Quarter1 Quarter2 Quarter3 

*Heteregenous effects tests

#delimit;
twoway (scatter n1 coef ,
ytit( "Effects of A on B")
ylabel(-7(7)0 0 " " -7 " ")
mlabel(sample)
mlabp(17)
xlabel(-0.2 (0.4) 0.1, grid)
xline(0, lp(dash)lcolor(brown)))

(rcap up low n1 ,
lp(dash) lcolor(gs1)
xscale(alt)
xtit("Coef. and 95% CIs in different samples")
legend(label(1 "Coef.") label(2 "95% CI")
col(1) ring(0) pos(7) size(small))
hori
text(-1 -70 "Panel A: By Risk",place(e) size(small))
text(-5 -70 "Panel B: By Location",place(e) size(small)))
;
delimit cr


*Parallel trend tests

gen policy = Stage - 8
tab policy
forvalues i = 7(-1)1{
	gen pre_`i' = (policy == -`i' & Treatment == 1) 
}

gen current = (policy == 0 & Treatment == 1)

forvalues j = 1(1)7{
	gen  post_`j' = (policy == `j' & Treatment == 1)
}

drop pre_1

xtnbreg Crash pre_* current  post_* i.Stage Distance_citycenter User Street_intersection Floor_area_ratio Speed Housing_price Entropy Bus_stop Third_street Second_street Parking_site Quarter

coefplot, baselevels ///
keep(pre_* current post_*) ///
vertical ///
yline(0,lcolor(edkblue*0.8)) ///
xline(7, lwidth(vthin) lpattern(dash) lcolor(teal)) ///
ylabel(,labsize(*0.75)) xlabel(,labsize(*0.75)) ///
ytitle("Coefficient", size(small)) ///
xtitle("Stage", size(small)) ///
addplot(line @b @at) ///
ciopts(lpattern(dash) recast(rcap) msize(medium)) ///
msymbol(circle_hollow) ///
scheme(s1mono)
